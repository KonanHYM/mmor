'use strict';

console.log('Hello, world.');

console.log('你好，我是popup！');
